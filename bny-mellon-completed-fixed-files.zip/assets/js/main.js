(function ($) {
    "use strict";

    jQuery(document).ready(function ($) {




        $('.header__nav__open').click(function () {

            $('.header__navigation').toggleClass('show');
            $(this).toggleClass('active')

        });


        $('.menu-close , .offcanvas-overlay').click(function () {

            $('.offcanvas-area , .offcanvas-overlay').removeClass('active');

        });

        $(document).mouseup(function (e) {
            var container = $(".header");

            // If the target of the click isn't the container
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                $('.header__nav__open').removeClass('active');
                $('.header__navigation').hide(100);
            }

        });

        $('.dropdown-open').click(function () {

            $('#filterDropdown').toggle();

        });


        // $(document).mouseup(function (e) {
        //     var container = $(".dropdown");

        //     // If the target of the click isn't the container
        //     if (!container.is(e.target) && container.has(e.target).length === 0) {
        //         $('#filterDropdown').hide();
        //     }

        // });
 




        $('.offcanvas-open').click(function () {

            $('.offcanvas-area, .offcanvas-overlay').addClass('active');

        });
        $('.sidebar-close, .offcanvas-overlay, .close-sidebar').click(function () {

            $('.offcanvas-area, .offcanvas-overlay').removeClass('active');

        });



        $("select").select2({
            theme: "bootstrap"
        });


        $(".report__card__slider").owlCarousel({
            items: 5,
            nav: true,
            dot: false,
            loop: false,
            margin: 20,
            autoplay: false,
            autoplayTimeout: 3000,
            smartSpeed: 1000,
            responsiveClass: true,
            navText: ["<i class='far fa-chevron-left'></i>", "<i class='far fa-chevron-right'></i>"],
            stagePadding: 100,
            responsive: {
                0: {
                    items: 1,
                    stagePadding: 45,
                    margin: 14,
                },
                575: {
                    items: 1,
                    margin: 12,
                    stagePadding: 90,
                },
                690: {
                    items: 2,
                    margin: 14,
                },
                768: {
                    items: 2,
                    margin: 14,
                },
                991: {
                    items: 3,
                    margin: 12,
                    stagePadding: 80,
                },
                1200: {
                    items: 3,
                    margin: 14,
                },
                1420: {
                    items: 4,
                    margin: 20,
                }
            }


        });





    });




}(jQuery));